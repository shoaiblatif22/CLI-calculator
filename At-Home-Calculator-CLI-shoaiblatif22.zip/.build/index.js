#!/usr/bin/env node
"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var import_chalk = __toESM(require("chalk"));
var import_clear = __toESM(require("clear"));
var import_figlet = __toESM(require("figlet"));
var import_commander = require("commander");
(0, import_clear.default)();
console.log(
  import_chalk.default.red(
    import_figlet.default.textSync("calculator-cli", { horizontalLayout: "full" })
  )
);
import_commander.program.version("0.0.1").description("A Calculator CLI").option(
  "-n1, --num1 <num1>",
  "Enter your first number: "
).option(
  "-o, --operation <operation>",
  "Operation to perform [add, subtract, multiply, divide]"
).option(
  "-n2, --num2 <num2>",
  "Enter your second number: "
).parse(process.argv);
if (!process.argv.slice(2).length) {
  import_commander.program.outputHelp();
} else {
  const options = import_commander.program.opts();
  const operation = options.operation;
  console.log(operation);
}
function isItANumber(str) {
  const maybeNumber = parseInt(str);
  const isNumber = !isNaN(maybeNumber);
  return isNumber;
}
function mainCalculator() {
  const firstNum = question("Enter your first number");
  const operator = question("Pick an operation to perform");
  const secondNum = question("Enter your second number");
}
//# sourceMappingURL=index.js.map
