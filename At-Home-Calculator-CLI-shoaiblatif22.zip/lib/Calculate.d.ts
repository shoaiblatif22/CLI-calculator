export declare function calculate(): void;
