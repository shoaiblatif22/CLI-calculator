#!/usr/bin/env node
import chalk from "chalk";
import clear from "clear";
import figlet from "figlet";
import { OptionValues, program } from "commander";


clear();
console.log(
  chalk.red(
    figlet.textSync('calculator-cli', { horizontalLayout: 'full'})
  )
);


program 
 .version ("0.0.1")
 .description("A Calculator CLI")
  .option("-o, --operation <operation>", "Operation to perform [add, subtract, multiply, divide]")
 .option(   "-n1, --num1 <num1>", "Enter your first number: ")
 .option("-n2, --num2 <num2>", "Enter your second number: ")
.parse(process.argv);

if(!process.argv.slice(2).length){
  program.outputHelp();
} else {
  const options: OptionValues = program.opts();
  const operation = options.operation;
  console.log(operation);
}



const options: OptionValues = program.opts();
const operation = options.operation;

if (operation === 'add') {
    console.log(+options.num1 + +options.num2);
}

if(operation === "subtract"){
console.log(options.num1 - options.num2);
}

if (operation === 'multiply') {
  console.log(options.num1 * options.num2);
}

if (operation === 'divide') {
    console.log(options.num1 / options.num2);
}


//Bonus: Create a multiply function without using the * symbol
/*  

  if (operation === 'multiply'){
     console.log(options.num1/(1/options.num2));
  }

*/



/*
//Step 1: Validate number
function isItANumber(str: string): boolean
{
    const maybeNumber = parseInt(str);
    const isNumber: boolean = !isNaN   
    (maybeNumber);
    return isNumber;
}

//Step 2: Validate operator
function isItAnOperator(operation:string):Boolean
{
  switch(operation)
  {
    case '+':
    case '-':
    case '*':
    case '/':
      return true;
    default:
      return false;
  }
    
}

if (operation === 'add') {
    console.log(options.num1 + options.num2);
}
if (operation === 'subtract') {
    console.log(options.num1 - options.num2);
}
if (operation === 'multiply') {
    console.log(options.num1 * options.num2);
}
if (operation === 'divide') {
    console.log(options.num1 / options.num2);
}

*/

