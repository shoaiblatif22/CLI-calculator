# Creating your own CLI

The aim of this task is to demonstrate all of the skills you have learned on day one of the Code Academy. Your goal will be to build a calculator tool that accepts input, performs an action and outputs the result.

> **What is a CLI?**<br>
A command-line interface recieves commands from the user in the form of lines of text. You'll see an example shortly 🙂

To make our lives easier it's possible to import and use code from other developers. Code can be shared through a `package`. This enables us to use another developers solution to a particular problem. For instance, later we'll use the `figlet` package which allows us to create ASCII Art from text.

It's necessary to have a package manager that will handle installing, upgrading, configuring and using all of our packages. For this project we will be using `yarn` - a package manager developed by Facebook.

## Set Up
Let's complete the initial set up for our CLI tool...

1. Open your `index.ts` file.
2. At the top of index.ts add `#!/usr/bin/env node`
3. Some packages have already been installed for you. Let's import them by adding:
```javascript
import chalk from "chalk";
import clear from "clear";
import figlet from "figlet";
import { OptionValues, program } from "commander";
```
> If you'd like to find out more about the packages we're using here:
> * https://github.com/chalk/chalk
> * https://github.com/bahamas10/node-clear
> * https://github.com/patorjk/figlet.js
> * https://github.com/tj/commander.js
4. Beneath the imports, let's add some code:
```javascript
// Clear the console when we call our cli
clear();
// Log to the console
console.log(
	// Make the console log "red" using the "chalk" library
  chalk.red(
		// Use the "figlet" library to write some cool text
    figlet.textSync('calculator-cli', { horizontalLayout: 'full' })
  )
);
```
5. In your console run `yarn build`.
> If you don't have a console tab open, you can find it in the left panel, under 'Tools'.
6. When the above is complete, run `yarn calculate`. You should see 'calculator-cli' text in the console.
> If the text is a little distorted, it probably doesn't have enough room to display. You can widen the console window by dragging the vertical divider on your screen. 
7. Add the snippet below to `index.ts`:
```javascript
program
  .version("0.0.1")
  .description("A Calculator CLI")
  .option(
    "-o, --operation <operation>",
    "Operation to perform [add, subtract, multiply, divide]"
  )
  .parse(process.argv);

if (!process.argv.slice(2).length) {
  program.outputHelp();
} else {
  const options: OptionValues = program.opts();
  const operation = options.operation;
  console.log(operation);
}
```
8. Run these two commands in your console (you'll need to run these commands every time you want to test your code):
    1. `yarn build`
    2. `yarn calculate -o add`
9. `add` should have been output in your console.

## Your Tasks
At the moment our CLI just outputs whichever operation you have selected:
```javascript
 console.log(operation);
```
You should aim to implement your calculator tool here instead. Remember, it should be able to do the following:
1. Allow the user to input two values.
2. Allow the user to choose an operation from those listed above.
3. Perform the operation and output the result.

**Not sure where to start?**<br>
Right now our CLI only accepts one input, `-o` or `--operation`, which will allow us to choose whether to add, subtract, etc. We need to provide inputs to perform this operation on, so the first thing you should consider is how to accept new arguments in the CLI to represent inputs.

To run different code based on the operation, you may want to use `if` statements to validate a `boolean`. e.g.:
```javascript
if (operation === "add") {
  // ADD THE TWO NUMBERS TOGETHER
}
```

Alternatively you could consider using `switch`:
```javascript
switch (operation) {
  case "add":
    // ADD THE TWO NUMBERS TOGETHER
    break;
}
```
A couple of useful links:

* https://www.tutorialsteacher.com/typescript/typescript-if-else
* https://www.tutorialsteacher.com/typescript/typescript-switch

Try to use the concepts we covered on day one. You could create a `calculator.ts` with functions for each operation, e.g.  `add()`. You could then   `export` this so that you can `import` it in `index.ts`.

> **Bonus**<br>
Can you create a multiply function **without** using the `*` symbol. Could we use a loop?<br>
Could you allow any number of inputs, not just two?<br>
What happens if you enter invalid data, such as text? How could we handle this?


### If you have any questions or need help feel free to drop one of us a message on Slack 👍